There is a quick example available to show what Updater can do.
Just run Updater.exe and you will see how Updater works. It will
download some files, but they will be deleted after the update, so
you don't have to worry about the files.

This example includes sequenced updating. Run Updater a few times to
see how sequences updating works.

NOTE:
Updater should be in this folder when executing this example!