Updater Tools - Readme
======================

This folder contains some easy tools for developers who
are using Updater. Each different application should
contain a custom readme.