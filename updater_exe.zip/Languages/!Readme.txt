There are several languages supported by Updater. You can download the newest 
language pack at

http://www.gvhsoftware.org 

If you want to translate Updater, please contact me via the website.